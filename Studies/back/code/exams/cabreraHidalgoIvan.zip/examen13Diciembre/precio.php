<?php

echo "<h2>Has comprado una entrada</h2>";

echo "Precio: " . $_POST['check'] . '€<br>';

echo "<form method='post' action='index.php'>";
echo "<input name='submit' type='submit' value='Volver'>";
echo "</form>";


?>



