// ============ Exercise 1 ============ \\
// ============ DATA ============ \\
const array = [null,undefined,true,false, "string", 1,"casa",NaN];
{
	// Copy the array and check if works
	const copyArray = [...array]; // No global copy
	console.log(copyArray);

// create a new element to store the array elements
	const types = {};
	for (const element of copyArray) {
		types[typeof element] = element;
		console.log(types);
	}
}

// ============ Exercise 2 ============ \\
// ============ DATA ============ \\
/*
* We create all the data we are going to use like the const max, the object defaultHuman,
* or all the new objects of humans to make the code cleaner.
* */

const max = 99999;
const arrayLotteryPlayers = [];

const defaultHuman = {
	name: "Dummies",
	lastName: "Dummies",
	lastName2: "Dummies",
	age: 0
}

const human1 = {name: "Wilfred", lastName: "Romualdo", lastName2: "Gonzalez", age:12, lottery: Math.floor(Math.random() * max)}
const human2 = {name: "Wilson", lastName: "Romualdo", lastName2: "Gonzalez", age:null}
const human3 = {name: "Wilfred", lastName: "Romualdo", lastName2: "Gonzalez", age: 32}
const human4 = {name: "Wilfred", lastName: "Romualdo", age:45}

// ============ FUNCTIONS ============ \\

function playLottery(human){
	const defaultHumanCopy = {...defaultHuman};
	const lotteryPlayer = {...defaultHumanCopy, ...human};
	lotteryPlayer.age ??= defaultHumanCopy.age;
	lotteryPlayer.lottery = lotteryPlayer.lottery ?? Math.floor(Math.random() * max);

	// Push the new object into the array of lottery players
	arrayLotteryPlayers.push(lotteryPlayer);
	return lotteryPlayer;
}

// ============ EXERCISE ============ \\
playLottery(human1);
playLottery(human2);
playLottery(human3);
playLottery(human4);

// show on the console the results of the humans objects
for (const index in arrayLotteryPlayers) {
	console.log(arrayLotteryPlayers[index]);
}
