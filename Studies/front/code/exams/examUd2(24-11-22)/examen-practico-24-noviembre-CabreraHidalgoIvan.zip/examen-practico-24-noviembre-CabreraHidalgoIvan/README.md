# Exam
1. Create an array of 10 elements which includes strings, numbers, booleans, undefined, NaN or null
   * Make a copy of the array with the spread operator
   * Create an object called types where the name of the property is the value of each element and the value is the type of each element.

2. Create a function playLottery that gets a human objects as a parameter and return another object (lotteryPlayer)
   1. Replace the properties null or undefined
   2. If the property lottery doesn't exist, create a random number


### Example

| name    | lastName | lastsName2 | Age | Lottery |
|---------|----------|------------|-----|---------|
| Wilfred | Romualdo | Gonzalez   | 12  | random  |
| Wilfred | Romualdo | Gonzalez   | 0   | random  |
| Wilfred | Romualdo | Gonzalez   | 32  | random  |
| Wilfred | Romualdo | Dummies    | 45  | random  |

### Code example
```const human1 = {name: "Wilfred", lastName: "Romualdo", lastName2: "Gonzalez", age:12, lottery: Math.floor(Math.random() * max)}```

[Enlace Google](https://google.com/)

